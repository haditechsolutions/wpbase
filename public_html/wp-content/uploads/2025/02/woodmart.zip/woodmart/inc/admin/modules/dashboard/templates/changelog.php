<div class="xts-box xts-theme-style">
	<div class="xts-box-header">
		<h3>
			<?php esc_html_e( 'Changelog', 'woodmart' ); ?>
		</h3>
	</div>

	<div class="xts-box-content">
		<iframe src="https://xtemos.com/woodmart-changelog.php?theme_settings" width="100%" height="500px"></iframe>
	</div>
</div>
