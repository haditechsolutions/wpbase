<?php

XTS\Modules\Theme_Settings_Backup\Main::get_instance()->render();
