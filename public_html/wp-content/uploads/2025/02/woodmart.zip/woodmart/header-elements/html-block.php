<?php woodmart_enqueue_inline_style( 'header-elements-base' ); ?>
<div class="wd-header-html wd-entry-content<?php echo woodmart_get_old_classes( ' whb-html-block-element' ); ?>"><?php echo woodmart_get_html_block( $params['block_id'] ); ?></div>
