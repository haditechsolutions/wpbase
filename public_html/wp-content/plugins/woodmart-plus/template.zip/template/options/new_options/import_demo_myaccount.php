<div class="item p-18 br-bottom">
   <span class="title"><?php esc_html_e('درون ریزی برخی صفحات داشبورد', 'woodmartplus'); ?></span>
   <p class="des"><?php esc_html_e('برخی صفحات اماده که در المنتور طراحی شده اند درون ریزی می شود', 'woodmartplus') ?></p>
   <div class="btn-select">
      <button class="chang-btn blue-btn-bg" name="import_myaccount" value="import"><?php esc_html_e('درونریزی', 'woodmartplus'); ?></button>
   </div>
</div>